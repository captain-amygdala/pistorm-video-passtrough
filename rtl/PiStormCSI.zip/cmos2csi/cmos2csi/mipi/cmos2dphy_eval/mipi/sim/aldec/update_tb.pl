use Aldec::ActiveHDL;

print $ARGV[0];

open(FILE, "<cmos2dphy_tb.v") || die "File not found";
my @lines = <FILE>;
close(FILE);

my @newlines;
foreach(@lines) {
   $_ =~ s/SIP7_inst/$ARGV[0]/g;
   push(@newlines,$_);
}

open(FILE, ">cmos2dphy_tb.v") || die "File not found";
print FILE @newlines;
close(FILE);
