Modify pixel2byte and pkt_formatter beh files to change non-blocking statements inside combinational blocks into block statements.
